#!/usr/bin/env python3
"""Offline integrity and independent PG18-vs-D40 replay verification."""
import argparse,decimal,gzip,hashlib,json,sys,types
from collections import Counter
from pathlib import Path

p=Path(__file__).resolve().parent
m=json.loads((p/'manifest.json').read_text())
sha=lambda data:hashlib.sha256(data).hexdigest()
files={item['original_relative_path']:item for item in m['files']}
assert len(files)==len(m['files'])
for item in m['files']:
 data=(p/item['object']).read_bytes()
 assert len(data)==item['size_bytes'] and sha(data)==item['sha256']
 assert len(gzip.compress(data,compresslevel=9,mtime=0))==item['individual_gzip_bytes']

def get(path):
 marker='/DBMS_C_plus_plus/'
 key=path.split(marker,1)[1] if marker in path else path
 item=files[key];return (p/item['object']).read_bytes()
def loadmodule(path,name):
 mod=types.ModuleType(name);mod.__file__=path;exec(compile(get(path),path,'exec'),mod.__dict__);return mod
base='build/pg-feature-identity-sequence-8d7tu384/'
a=loadmodule(base+'independent_reply_decoder_v1.py','decoder_a').decode
b=loadmodule(base+'second_reply_decoder_v1.py','decoder_b').decode
trace=json.loads(get(base+'identity-exp-carry-study-r1-wire-PG-v1/trace-v1.json'))
d40=json.loads(get('build/numeric-exp-draft/candidate-D40-pg317-wire/audit.json'))
assert len(trace['records'])==len(d40['records'])==317 and trace['complete'] and d40['complete']
def fits(value):
 n=decimal.Decimal(value)
 if not n.is_finite():return True
 t=n.as_tuple();return max(0,-t.exponent)<=1000 and (not n or len(t.digits)+max(0,t.exponent)<=1000)
counts=Counter()
for left,right in zip(trace['records'],d40['records']):
 assert left['id']==right['id'] and left['input']==right['input']
 req=get(left['request_path']);pgraw=get(left['response_path']);dbraw=get(right['dbms_response_path'])
 assert sha(req)==left['request_sha256']==right['request_sha256']
 assert sha(pgraw)==left['response_sha256']==right['pg_response_sha256'] and sha(dbraw)==right['dbms_response_sha256']
 pg=a(pgraw);db=a(dbraw);assert pg==b(pgraw) and db==b(dbraw) and db['ready']==['I']
 if pg['state']:
  assert pg['state']==db['state']=='22003' and not db['rows'];counts['pg_22003']+=1
 elif not fits(left['input']) or not fits(pg['rows'][0][0]):
  assert db['state']=='22003' and not db['rows'];counts['project_limit']+=1
 else:
  assert db['state'] is None and pg['rows']==db['rows'] and pg['tags']==db['tags']
  assert [[(x[0],x[3]) for x in row] for row in pg['descriptors']]==[[(x[0],x[3]) for x in row] for row in db['descriptors']]
  counts['exact_pg']+=1
assert counts=={'exact_pg':293,'project_limit':23,'pg_22003':1}
r='build/numeric-exp-draft/'
inputs=get(r+'pg-random-input.txt').decode().splitlines();pgvalues=get(r+'pg-random-raw.txt').decode().splitlines();answers=get(r+'pg-random-output.txt').decode().splitlines();assert len(inputs)==len(pgvalues)==len(answers)==1018
for value,answer in zip(pgvalues,answers):
 digits=value.replace('.','').lstrip('0');expected='RANGE' if len(digits)>1000 else 'OK\t'+str(len(value.partition('.')[2]))+'\t'+value
 assert (expected=='RANGE' and answer.startswith('RANGE\t')) or expected==answer
s=json.loads(get(r+'sanitizer-results.json'));assert len(s)==3 and all(x['exit']==0 and x['stderr_bytes']==0 and x['stdout_matches_nonsanitized'] for x in s)
print('verified objects',len({v['sha256'] for v in m['files']}),'original files',len(files),'PG/D40 wire',dict(counts),'PG/decimal component corpus',len(inputs),'sanitizer runs',len(s))
assert 'hard-coded' in m['exit_status_limitations']
print('NOTE: historical driver_exit is hard-coded; outer-process wait receipts are not archived; server evidence is Popen.wait only, without server log or PGID')
parser=argparse.ArgumentParser();parser.add_argument('--restore',type=Path);args=parser.parse_args()
if args.restore:
 dest=args.restore.resolve();dest.mkdir(parents=True,exist_ok=True)
 for name,item in files.items():
  target=(dest/name).resolve();assert dest in target.parents
  target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as f:f.write((p/item['object']).read_bytes())
 print('restored',len(files),'original-path files under',dest)
