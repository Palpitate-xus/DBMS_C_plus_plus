# PostgreSQL 18 numeric exponential evidence bundle

This small bundle preserves the original frames and audit material for the D40 candidate, without including a database data directory, object file, server executable, or repeated byte-identical files. `manifest.json` maps every original project-relative path to its original SHA-256, byte size, individual gzip size, and deduplicated content object. Individual gzip sizes are estimates per file and do not add up to the solid archive size. Absolute paths embedded in original traces are unchanged; the verifier resolves them through the manifest.

After extracting the archive into an empty directory, run:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 verify_bundle.py
```

The offline verifier hashes every object and independently decodes the 317 PostgreSQL and D40 wire responses with both archived decoders. It also checks the 1,018-case PostgreSQL-versus-decimal-component corpus and the saved sanitizer receipts. Expected outcome: 293 exact D40/PG text-protocol matches, 23 D40 `22003` results for the project's 1,000-digit representation limit, one `22003` on both, and no unexpected mismatch. The 1,018-case corpus is a component comparison against PG via psql, not a database wire result. ASan/UBSan results are component-level, not a claim that the complete server was sanitized.

To reconstruct the original relative paths without overwriting existing files, run `python3 verify_bundle.py --restore /tmp/dbms-evidence-restored`. The archive excludes binaries and PostgreSQL installation/data; rerunning the database test requires a built D40 executable and PostgreSQL 18.6. Original scripts can require adjusted workspace/binary paths. To independently repeat the component sanitizer checks after restoration:

```sh
bash /tmp/dbms-evidence-restored/build/numeric-exp-draft/evidence-pack-staging/reproduce_sanitizers.sh
```

D40 executable SHA-256: `25dad0eef51b8af34e628ead2a9633696cf6847ba026a66954ba3b1c1d53fc7e`. See the archived freeze receipt, process/lifecycle receipt, individual audit records, and PostgreSQL license. These are finite sampled comparisons, not a proof of full PostgreSQL compatibility. Existing binary Numeric input limitations remain outside this text-protocol comparison.

## Exit-status evidence limitation

The archived historical `independent-audit.json` contains `driver_exit: 0` as a hard-coded value. It is **not** a captured driver wait status. The interactive tool transcript separately showed exit code 0 for the collection driver (session 20513, final chunk 9a5cab) and for the independent audit (synchronous execution, chunk 50b194), but no separately verifiable terminal/wait record was saved for those outer processes. Thus the archived files alone do not independently establish their actual exit codes. `tool-observations.md` is a manual transcription of those tool observations, not a machine-authenticated terminal record.

The database server's `actual_server_exit: 0` in the driver's audit was read from `Popen.returncode` after `Popen.wait()` via `runner.stop_ours`; the separate audit subsequently observed its PID no longer existed. No server log or process-group lifecycle record was retained. Keep the original historical JSON unchanged; ignore its hard-coded driver field as evidence.
