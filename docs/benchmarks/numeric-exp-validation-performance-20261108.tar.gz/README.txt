D40 supplemental evidence. Verify all content and dependencies with: python3 verify_D40_supplemental_evidence_v3.py ARCHIVE REPOSITORY_ROOT
See index.json for provenance, scope and limitations. Data, database snapshots and ELF are excluded.
