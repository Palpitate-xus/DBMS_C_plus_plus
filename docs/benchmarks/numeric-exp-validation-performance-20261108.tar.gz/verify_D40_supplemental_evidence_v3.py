#!/usr/bin/env python3
"""Verify every D40 evidence object and its exact older-archive dependencies."""
import base64,gzip,hashlib,json,subprocess,sys,tarfile
from pathlib import Path
archive=Path(sys.argv[1]);root=Path(sys.argv[2]);H=lambda b:hashlib.sha256(b).hexdigest()
with tarfile.open(archive,'r:gz') as tf:
 index=json.load(tf.extractfile('index.json'));names=tf.getnames();assert len(names)==len(set(names));assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
 required={x['sha256'] for x in index['files'].values()};store={}
 for member in tf:
  if member.isfile() and member.name.startswith('objects/'):
   h=member.name.split('/')[-1];b=tf.extractfile(member).read();assert H(b)==h and h not in store;store[h]=b
 assert set(store)==set(index['local_object_sha256'])
for n,expected in index['dependencies'].items():
 p=root/n;assert p.is_file() and H(p.read_bytes())==expected,(n,'dependency SHA mismatch')
missing=required-set(store)
for n,prefix in [('docs/benchmarks/numeric-func-division-evidence-20261108.tar.gz','blobs/'),('docs/benchmarks/numeric-exp-evidence-20261108.tar.gz','objects/')]:
 with tarfile.open(root/n,'r|gz') as tf:
  for member in tf:
   if member.isfile() and member.name.startswith(prefix):
    h=member.name.split('/')[-1]
    if h in missing:
     b=tf.extractfile(member).read();assert H(b)==h;store[h]=b;missing.discard(h)
for n in ['docs/benchmarks/numeric-attribution-evidence-20261108.json.gz','docs/benchmarks/numeric-tochar-performance-increment-20261108.json.gz','docs/benchmarks/numeric-catalog-evidence-20261108.json.gz']:
 with gzip.open(root/n,'rt') as f:data=json.load(f)
 for h,b64 in data['blobs_base64_by_sha256'].items():
  if h in missing:
   b=base64.b64decode(b64,validate=True);assert H(b)==h;store[h]=b;missing.discard(h)
tree=subprocess.check_output(['git','-C',str(root),'ls-tree','-r',index['git_head'],'--','src','tests'],text=True)
tracked={line.split('\t',1)[1]:line.split()[2] for line in tree.splitlines()}
for h,git in index['git_objects'].items():
 assert tracked.get(git['path'])==git['blob'],('Git path/blob mismatch',git['path'])
 if h in missing:
  b=subprocess.check_output(['git','-C',str(root),'cat-file','blob',git['blob']]);assert H(b)==h;store[h]=b;missing.discard(h)
assert not missing,('missing dependency objects',sorted(missing)[:10])
for path,meta in index['files'].items():
 b=store[meta['sha256']];assert len(b)==meta['bytes'] and H(b)==meta['sha256'],path
print('verified logical files',len(index['files']),'unique objects',len(required),'local objects',len(index['local_object_sha256']),'dependencies',len(index['dependencies']))
